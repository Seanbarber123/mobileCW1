package com.example.com594cw12020;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class signUp extends AppCompatActivity {
    LoginDataBaseAdapter loginDatabaseAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        //Create an instance of SQLite database
        loginDatabaseAdapter = new LoginDataBaseAdapter(this);
        loginDatabaseAdapter = loginDatabaseAdapter.open();
    }

    public void SignUP_OK(View view){
        String username = ((EditText)findViewById(R.id.editText_reg_Username)).getText().toString();
        String email = ((EditText)findViewById(R.id.editText_reg_email)).getText().toString();
        String password = ((EditText)findViewById(R.id.editText_reg_password)).getText().toString();
        String confirmPassword = ((EditText)findViewById(R.id.editText_reg_cpassword)).getText().toString();
        String gender = ((RadioGroup)findViewById(R.id.radioGroup)).toString();
        String male = ((RadioButton)findViewById(R.id.radioButton_male)).toString();
        String female = ((RadioButton)findViewById(R.id.radioButton_female)).toString();


        if (!validUsername(username) && !validEmail(email) && !validPassword(password)) {

            Toast.makeText(getApplicationContext(), "Username must start with an uppercase and have 4-8 characters. \n + " +
                            "Mst be a valid email address. \n" +
                            "Password(5-9)must contain an uppercase, lowercase, a number and a special character.",
                    Toast.LENGTH_LONG).show();
        }
        else if (!validUsername(username) && !validEmail(email)) {
            Toast.makeText(getApplicationContext(), "Username(4-8 long) must start with an uppercase. \n + " +
                    "Email  must be a valid email. \n",
                    Toast.LENGTH_LONG).show();
        }
        else if  (!validPassword(password) && !validEmail(email)){
            Toast.makeText(getApplicationContext(), "Email  must be a valid email. \n" +
                            "Password(5-9)must contain an uppercase, lowercase, a number and a special character.",
                    Toast.LENGTH_LONG).show();
        }
        else if (!validPassword(password) && !validUsername(username)){
            Toast.makeText(getApplicationContext(), "Username(4-8 long) must start with an uppercase. \n + " +
                            "Password(5-9)must contain an uppercase, lowercase, a number and a special character.",
                    Toast.LENGTH_LONG).show();
        }
        else if (!validPassword(password)) {
            Toast.makeText(getApplicationContext(),
                            "Password(5-9)must contain an uppercase, lowercase, a number and a special character.\n",
                    Toast.LENGTH_LONG).show();
        }
        else if (!validUsername(username)) {
            Toast.makeText(getApplicationContext(), "Username(4-8 long) must start with an uppercase. \n ",
                    Toast.LENGTH_LONG).show();
        }
        else if (!validEmail(email)) {
            Toast.makeText(getApplicationContext(),
                            "Email  must be a valid email. \n",
                    Toast.LENGTH_LONG).show();
        }
        else if (validPassword(password) && validUsername(username) && validEmail(email))
        {
            if (!password.equals(confirmPassword)) {
                Toast.makeText(getApplicationContext(), "Passwords do not match",
                        Toast.LENGTH_LONG).show();
            } else {
                //Save the data to the database
                loginDatabaseAdapter.insertEntry(username, email, password, gender);
                Toast.makeText(getApplicationContext(),
                        "Accounted created! You can now sign in",
                        Toast.LENGTH_LONG).show();
                Intent intent = new Intent(signUp.this, MainActivity.class);
                startActivity(intent);
            }
        }
        else
        {
            Toast.makeText(getApplicationContext(),
                    "Data does not meet criteria",
                    Toast.LENGTH_LONG).show();
        }

    }

    public boolean validEmail(String example)
    {
        if(example.matches("\\b[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}\\b"))
        {
            return true;
        }

        return false;
    }

    public boolean validPassword(String example)
    {
        if(example.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@$!%*?&])[A-Za-z[0-9]@$!%*?&]{5,9}$"))
        {
            return true;
        }

        return false;
    }

    public boolean validUsername(String example)
    {
        if(example.length() > 3 && example.length() < 9) {
            if (example.matches("^[A-Z].*")) {
                return true;
            }
        }
        return false;
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        loginDatabaseAdapter.close();
    };
}