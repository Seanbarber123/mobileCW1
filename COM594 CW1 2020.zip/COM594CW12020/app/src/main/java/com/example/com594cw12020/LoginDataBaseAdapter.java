package com.example.com594cw12020;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.service.autofill.UserData;

import java.util.ArrayList;

public class LoginDataBaseAdapter {
    //Database Version
    private static final int DATABASE_VERSION = 1;
    //Database Name
    private static final String DATABASE_NAME = "Login.db";
    //Variable to hold the database instance
    private static SQLiteDatabase db;
    //Database open/upgrade helper
    private DataBaseHelper dataBaseHelper;

    //Constructor
    public LoginDataBaseAdapter(Context context) {
        dataBaseHelper = new DataBaseHelper(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //Method to open the database
    public LoginDataBaseAdapter open() throws SQLException {
        db = dataBaseHelper.getWritableDatabase();
        return this;
    }

    //Method to close the database
    public void close() {
        db.close();
    }

    //Method returns an instance of the Database
    public SQLiteDatabase getDatabaseInstance() {
        return db;
    }

    //Insert username, email, password and gender into the table
    public void insertEntry(String un, String em, String pw, String gr) {
        ContentValues newValues = new ContentValues();
        //Assign values for each row
        newValues.put("userName", un);
        newValues.put("Email", em);
        newValues.put("userPassword", pw);
        newValues.put("Gender", gr);
        //Insert the row into your table
        db.insert("User", null, newValues);
    }

    //Find password for each specific username
    public String getSingleEntry(String un) {
        db = dataBaseHelper.getReadableDatabase();
        Cursor cursor = db.query("User", null, "Username=?",
                new String[]{un}, null, null, null);
        if (cursor.getCount() < 1) //Username not exist
        {
            cursor.close();
            return "Not Exist";
        }
        cursor.moveToFirst();
        String getPassword = cursor.getString(cursor.getColumnIndex("userPassword"));
        cursor.close();
        return getPassword;
    }


    /*//Retrieve username and password from database
    public ArrayList<String> getUsers() {
        SQLiteDatabase db = dataBaseHelper.getReadableDatabase();
        ArrayList<String> arrayList = new ArrayList<String>();

        Cursor cursor = db.rawQuery("select * from User", null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            arrayList.add(cursor.getString(cursor.getColumnIndex("username")));
            cursor.moveToNext();
        }
        return arrayList;
    }*/
}
