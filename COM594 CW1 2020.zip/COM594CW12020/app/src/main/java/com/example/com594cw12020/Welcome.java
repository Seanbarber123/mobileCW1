package com.example.com594cw12020;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;


public class Welcome extends AppCompatActivity {

    DataBaseHelper dataBaseHelper;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        TextView txtname = (TextView) findViewById(R.id.textView_Welcome);
        Intent intent = getIntent();
        String loginName = intent.getStringExtra("Name");
        txtname.setText("Welcome, " + loginName);

        //final DataBaseHelper helper = new DataBaseHelper(this);
        final ArrayList array_list = dataBaseHelper.getUsers();
        listView = findViewById(R.id.listViewUsers);

        final ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, array_list);
        listView.setAdapter(arrayAdapter);

    }

    public void logOutOK(View view){
        Intent intent = new Intent( this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}


